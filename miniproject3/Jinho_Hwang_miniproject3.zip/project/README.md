# Usage

## Running the program

```
bash test.sh
```

## The output

1. The output of my program resides in ./output/output.csv.
1. Statistics are shown in stdout.