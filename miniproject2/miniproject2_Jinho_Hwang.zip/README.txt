run_all.bash is a script to make, run, clean and show all the neccessary output.

Run convenently with following:
```
bash run_all.bash {test_txt | default=./tests/schedule.txt}
```
will run test_txt schedule with all scheduling algorithms and output on stdout.
